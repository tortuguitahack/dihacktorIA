export interface Expert {
  id: string;
  name: string;
  niche: string;
  focus: string;
}

export interface GeneratedCourse {
  id: string;
  title: string;
  expertName: string;
  niche: string;
  description: string;
  price: number;
  contentMarkdown?: string;
  coverImagePrompt?: string;
  coverImageUrl?: string;
  category?: string;
  categoryLabel?: string;
  categoryColor?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
}

export enum ImageAspectRatio {
  Square = "1:1",
  Portrait = "9:16",
  Landscape = "16:9",
  Wide = "21:9"
}

// Payment Interfaces
export type PaymentProvider = 'Stripe' | 'KucoinPay' | 'Crypto' | 'BankTransfer';

export interface BankAccountDetails {
  holder: string;
  routing?: string;
  account?: string;
  bank: string;
  type?: string;
  iban?: string;
  bic?: string;
  id?: string;
}

export interface PaymentConfig {
  gateways: {
    provider: PaymentProvider;
    currency?: string;
    destination_account?: string | string[];
    payout_schedule?: string;
    key?: string;
    secret?: string;
    wallets?: {
      USDC: string;
      USDT: string;
      BTC: string;
      ETH: string;
    };
    blockchain_api_key?: string;
    accounts?: {
      [key: string]: BankAccountDetails;
    };
  }[];
  emergency_stop: boolean;
}