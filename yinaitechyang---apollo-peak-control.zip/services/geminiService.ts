import { GoogleGenAI, Type } from "@google/genai";
import { ImageAspectRatio } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateCourseSyllabus = async (expertName: string, niche: string, topic: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are simulating the mind of ${expertName}, a world-class expert in ${niche}. 
      Create a detailed syllabus and sales copy for a digital product titled "${topic}".
      Format the response in Markdown. Include:
      1. A viral, high-FOMO Title.
      2. A 100-word hypnotic sales description.
      3. A detailed module breakdown (Week 1 to Week 4).
      4. A list of included tools (checklists, n8n workflows, prompts).
      5. A price of $9.99.
      Keep it practical, ethical, and actionable.`,
      config: {
        tools: [{ googleSearch: {} }], // Grounding for latest trends
      }
    });
    return response.text;
  } catch (error) {
    console.error("Error generating course:", error);
    throw error;
  }
};

export const consultTheCollective = async (query: string) => {
  try {
    // Thinking model for complex strategy
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: query,
      config: {
        systemInstruction: "You are DIHACKTOR AGENTE SUPREMO, the collective mind of 1000 experts. You provide direct, high-level, actionable business and technical advice. You do not fluff. You give raw truth.",
        thinkingConfig: { thinkingBudget: 32768 }, 
      }
    });
    return response.text;
  } catch (error) {
    console.error("Error consulting collective:", error);
    throw error;
  }
};

export const generateCoverArt = async (prompt: string, aspectRatio: ImageAspectRatio) => {
  try {
    // Determine user's selected API key first if needed (omitted for this simplified logic as per instructions, assuming process.env)
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
          imageSize: "1K"
        }
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    throw error;
  }
};