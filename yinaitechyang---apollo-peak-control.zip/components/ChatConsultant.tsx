import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { consultTheCollective } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

interface ChatConsultantProps {
  onBuyAccess: () => void;
}

const ChatConsultant: React.FC<ChatConsultantProps> = ({ onBuyAccess }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Soy DIHACKTOR. Tengo acceso a la mente de 1000 expertos. Puedo crear cualquier producto o resolver cualquier duda. ¿Qué necesitas?" }
  ]);
  const [input, setInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  // State to track if we are in 'payment required' mode
  const [paymentRequired, setPaymentRequired] = useState(false);
  
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");

    // If we haven't paid yet, interrupt the flow
    if (!paymentRequired) {
      setIsThinking(true);
      // Simulate "thinking" or processing before asking for payment
      setTimeout(() => {
        const payMsg: ChatMessage = { 
          role: 'model', 
          text: "Entendido. Tengo la respuesta exacta y el plan de acción de los expertos para esto. \n\nPara revelar esta información estratégica y generar el producto completo, se requiere un acceso de **$9.99**.\n\n¿Mediante qué método de pago le gustaría proceder?" 
        };
        setMessages(prev => [...prev, payMsg]);
        setPaymentRequired(true);
        setIsThinking(false);
      }, 1000);
      return;
    }
    
    // If we are in payment mode, triggering send again might mean they want to pay or are asking how
    // But realistically, we show a button below. If they type "card" or "crypto", we can trigger the modal.
    if (paymentRequired) {
       onBuyAccess(); // Trigger the modal from App.tsx
       return;
    }
  };

  return (
    <div className="bg-[#111] rounded-xl border border-[#222] h-[600px] flex flex-col">
      <div className="p-4 border-b border-[#222] bg-[#0a0a0a] rounded-t-xl">
        <h3 className="font-bold text-lg flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
          Consultor Agente Supremo (1000 Expertos)
        </h3>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-3 rounded-lg text-sm ${m.role === 'user' ? 'bg-white text-black' : 'bg-[#222] text-gray-200'}`}>
              <ReactMarkdown>{m.text}</ReactMarkdown>
            </div>
          </div>
        ))}
        {isThinking && (
          <div className="flex justify-start">
            <div className="bg-[#222] text-gray-400 p-3 rounded-lg text-sm italic animate-pulse">
              Consultando a la red neuronal de expertos...
            </div>
          </div>
        )}
        
        {/* Payment Trigger Button appearing inside chat when required */}
        {paymentRequired && !isThinking && (
           <div className="flex justify-start">
              <button 
                onClick={onBuyAccess}
                className="bg-green-600 hover:bg-green-500 text-white px-6 py-3 rounded-lg font-bold text-sm shadow-lg transition-all animate-bounce-slow"
              >
                🔓 Pagar $9.99 para desbloquear respuesta
              </button>
           </div>
        )}

        <div ref={bottomRef} />
      </div>

      <div className="p-4 border-t border-[#222] bg-[#0a0a0a] rounded-b-xl">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={paymentRequired ? "Haz clic en el botón para pagar..." : "Pregunta a los 1000 expertos..."}
            disabled={paymentRequired}
            className="flex-1 bg-[#111] border border-[#333] text-white p-3 rounded focus:outline-none focus:border-white transition-colors disabled:opacity-50"
          />
          <button 
            onClick={handleSend}
            disabled={isThinking || paymentRequired}
            className="bg-white text-black px-6 py-3 rounded font-bold hover:bg-gray-200 disabled:opacity-50"
          >
            Enviar
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatConsultant;