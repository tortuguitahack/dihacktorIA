import React, { useState } from 'react';
import { PAYMENT_CONFIG } from '../constants';
import { GeneratedCourse, BankAccountDetails } from '../types';

interface CheckoutModalProps {
  product: GeneratedCourse;
  onClose: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ product, onClose }) => {
  const [activeTab, setActiveTab] = useState<'card' | 'crypto' | 'bank'>('card');
  const [selectedCrypto, setSelectedCrypto] = useState<'USDT' | 'BTC' | 'ETH' | 'USDC'>('USDT');
  const [selectedRegion, setSelectedRegion] = useState<string>('USA');
  const [copied, setCopied] = useState(false);

  // Helper to get Stripe Link
  const getStripeLink = () => {
    const stripeGateway = PAYMENT_CONFIG.gateways.find(g => g.provider === 'Stripe');
    if (!stripeGateway?.destination_account) return '#';
    
    // If it's an array, pick a random one to load balance (simulated)
    const accounts = Array.isArray(stripeGateway.destination_account) 
      ? stripeGateway.destination_account 
      : [stripeGateway.destination_account];
      
    // Simple round-robin or random logic
    const randomIndex = Math.floor(Math.random() * accounts.length);
    return accounts[randomIndex];
  };

  const getCryptoWallet = (type: string) => {
     const cryptoGateway = PAYMENT_CONFIG.gateways.find(g => g.provider === 'Crypto');
     return cryptoGateway?.wallets?.[type as keyof typeof cryptoGateway.wallets] || 'Error loading wallet';
  };

  const getBankDetails = (region: string): BankAccountDetails | null => {
      const bankGateway = PAYMENT_CONFIG.gateways.find(g => g.provider === 'BankTransfer');
      return bankGateway?.accounts?.[region] || null;
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currentBank = getBankDetails(selectedRegion);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#111] w-full max-w-lg rounded-2xl border border-[#333] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-[#222] bg-[#0a0a0a]">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-xl font-bold text-white mb-1">Pasarela de Pago Segura</h2>
              <p className="text-sm text-gray-400">Estás adquiriendo: <span className="text-green-400">{product.title}</span></p>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">$9.99</span>
            <span className="text-sm text-gray-500 line-through">$497.00</span>
            <span className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded ml-2">OFERTA FLASH</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#222] bg-[#151515]">
          <button 
            onClick={() => setActiveTab('card')}
            className={`flex-1 py-4 text-sm font-medium transition-colors border-b-2 ${activeTab === 'card' ? 'border-green-500 text-white bg-[#1a1a1a]' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            💳 Tarjeta (Stripe)
          </button>
          <button 
            onClick={() => setActiveTab('crypto')}
            className={`flex-1 py-4 text-sm font-medium transition-colors border-b-2 ${activeTab === 'crypto' ? 'border-blue-500 text-white bg-[#1a1a1a]' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            ₿ Cripto
          </button>
          <button 
            onClick={() => setActiveTab('bank')}
            className={`flex-1 py-4 text-sm font-medium transition-colors border-b-2 ${activeTab === 'bank' ? 'border-purple-500 text-white bg-[#1a1a1a]' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
          >
            🏦 Transferencia
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto">
          
          {/* CARD TAB */}
          {activeTab === 'card' && (
            <div className="space-y-6 text-center py-4">
              <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>
              </div>
              <p className="text-gray-300 text-sm mb-6">
                Procesamiento seguro via Stripe. Acceso inmediato al producto después de la confirmación.
              </p>
              <a 
                href={getStripeLink()} 
                target="_blank" 
                rel="noopener noreferrer"
                className="block w-full bg-[#635BFF] hover:bg-[#534ae3] text-white font-bold py-4 rounded-lg transition-all transform hover:scale-[1.02] shadow-lg shadow-[#635BFF]/20"
              >
                Pagar con Tarjeta de Crédito ($9.99)
              </a>
              <div className="flex justify-center gap-4 mt-6 grayscale opacity-50">
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-6" alt="Visa" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="h-6" alt="Mastercard" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" className="h-6" alt="Paypal" />
              </div>
            </div>
          )}

          {/* CRYPTO TAB */}
          {activeTab === 'crypto' && (
            <div className="space-y-4">
               <div className="grid grid-cols-4 gap-2 mb-4">
                  {['USDT', 'BTC', 'ETH', 'USDC'].map(coin => (
                    <button 
                      key={coin}
                      onClick={() => setSelectedCrypto(coin as any)}
                      className={`py-2 text-xs rounded border ${selectedCrypto === coin ? 'bg-blue-500/20 border-blue-500 text-blue-400' : 'bg-black border-[#333] text-gray-500 hover:border-gray-500'}`}
                    >
                      {coin}
                    </button>
                  ))}
               </div>

               <div className="bg-black p-4 rounded-lg border border-[#333] text-center">
                  <p className="text-xs text-gray-500 mb-2 uppercase tracking-wide">Dirección de Billetera ({selectedCrypto})</p>
                  <div className="flex items-center justify-between gap-2 bg-[#1a1a1a] p-3 rounded border border-[#222]">
                    <code className="text-xs text-gray-300 break-all font-mono">
                      {getCryptoWallet(selectedCrypto)}
                    </code>
                    <button 
                      onClick={() => handleCopy(getCryptoWallet(selectedCrypto))}
                      className="text-gray-400 hover:text-white p-1"
                    >
                      {copied ? (
                         <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                      ) : (
                         <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                      )}
                    </button>
                  </div>
               </div>

               <div className="bg-yellow-500/10 border border-yellow-500/20 p-3 rounded text-xs text-yellow-200">
                 ⚠️ <strong>Importante:</strong> Envía solo {selectedCrypto} a esta dirección. Envía el comprobante de transacción a soporte para liberar tu acceso manual.
               </div>
               <button className="w-full bg-[#111] hover:bg-[#222] border border-[#333] text-white py-3 rounded font-medium mt-2">
                 He enviado el pago
               </button>
            </div>
          )}

          {/* BANK TAB */}
          {activeTab === 'bank' && (
             <div className="space-y-4">
                <div className="mb-4">
                   <label className="block text-xs text-gray-500 mb-2">Región Bancaria</label>
                   <select 
                      value={selectedRegion}
                      onChange={(e) => setSelectedRegion(e.target.value)}
                      className="w-full bg-black border border-[#333] text-white p-3 rounded focus:outline-none"
                   >
                      <option value="USA">🇺🇸 Estados Unidos (ACH/Wire)</option>
                      <option value="Europe">🇪🇺 Europa (SEPA)</option>
                      <option value="Luxembourg">🇱🇺 Luxemburgo (VIP)</option>
                      <option value="Bolivia">🇧🇴 Bolivia (Local)</option>
                   </select>
                </div>

                {currentBank && (
                  <div className="bg-[#1a1a1a] rounded-lg p-4 border border-[#333] space-y-3">
                    <div className="flex justify-between border-b border-[#333] pb-2">
                       <span className="text-gray-500 text-xs">Beneficiario</span>
                       <span className="text-white text-xs font-bold text-right">{currentBank.holder}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#333] pb-2">
                       <span className="text-gray-500 text-xs">Banco</span>
                       <span className="text-white text-xs font-bold text-right">{currentBank.bank}</span>
                    </div>
                    {currentBank.account && (
                      <div className="flex justify-between border-b border-[#333] pb-2">
                        <span className="text-gray-500 text-xs">Cuenta / No.</span>
                        <span className="text-white text-xs font-mono text-right">{currentBank.account}</span>
                      </div>
                    )}
                    {currentBank.routing && (
                      <div className="flex justify-between border-b border-[#333] pb-2">
                        <span className="text-gray-500 text-xs">Routing</span>
                        <span className="text-white text-xs font-mono text-right">{currentBank.routing}</span>
                      </div>
                    )}
                     {currentBank.iban && (
                      <div className="flex justify-between border-b border-[#333] pb-2">
                        <span className="text-gray-500 text-xs">IBAN</span>
                        <span className="text-white text-xs font-mono text-right">{currentBank.iban}</span>
                      </div>
                    )}
                     {currentBank.bic && (
                      <div className="flex justify-between">
                        <span className="text-gray-500 text-xs">SWIFT/BIC</span>
                        <span className="text-white text-xs font-mono text-right">{currentBank.bic}</span>
                      </div>
                    )}
                  </div>
                )}
                 <p className="text-xs text-center text-gray-500 mt-4">
                  Las transferencias pueden tardar de 1 a 3 días hábiles.
                </p>
             </div>
          )}

        </div>
        
        <div className="p-4 bg-[#0a0a0a] border-t border-[#222] text-center">
            <p className="text-[10px] text-gray-600">🔒 Encriptación SSL de 256-bits. Tus datos están protegidos por Apollo Peak Security Protocol.</p>
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;