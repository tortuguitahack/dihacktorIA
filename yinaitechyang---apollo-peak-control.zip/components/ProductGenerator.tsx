import React, { useState } from 'react';
import { EXPERTS, NICHES } from '../constants';
import { generateCourseSyllabus, generateCoverArt } from '../services/geminiService';
import { ImageAspectRatio, GeneratedCourse } from '../types';
import ReactMarkdown from 'react-markdown';

interface ProductGeneratorProps {
  onBuy: (course: GeneratedCourse) => void;
}

const ProductGenerator: React.FC<ProductGeneratorProps> = ({ onBuy }) => {
  const [selectedExpert, setSelectedExpert] = useState(EXPERTS[0]);
  const [selectedNiche, setSelectedNiche] = useState(NICHES[0]);
  const [customTopic, setCustomTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<ImageAspectRatio>(ImageAspectRatio.Square);
  
  // To store the generated product object to pass to onBuy
  const [generatedProduct, setGeneratedProduct] = useState<GeneratedCourse | null>(null);

  const handleGenerate = async () => {
    if (!customTopic) return;
    setLoading(true);
    setResult(null);
    setGeneratedImage(null);
    setGeneratedProduct(null);

    try {
      // Parallel generation for speed
      const textPromise = generateCourseSyllabus(selectedExpert.name, selectedNiche, customTopic);
      const imagePromise = generateCoverArt(
        `Professional digital product cover for a course named "${customTopic}" by ${selectedExpert.name} in style of ${selectedNiche}. Minimalist, high quality, dark mode aesthetic, 8k resolution.`,
        aspectRatio
      );

      const [text, image] = await Promise.all([textPromise, imagePromise]);
      
      setResult(text || "Error generating text.");
      if (image) setGeneratedImage(image);

      // Create a temporary course object for purchase
      if (text) {
        setGeneratedProduct({
            id: `GEN-${Date.now()}`,
            title: customTopic,
            expertName: selectedExpert.name,
            niche: selectedNiche,
            description: "Producto generado exclusivamente por IA bajo demanda.",
            price: 9.99,
            contentMarkdown: text,
            coverImageUrl: image || undefined,
            category: "Expert",
            categoryLabel: "🧠 EXPERT · On Demand",
            categoryColor: "text-blue-400"
        });
      }

    } catch (error) {
      console.error(error);
      setResult("Error generating product. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#111] p-6 rounded-xl border border-[#222]">
      <h2 className="text-2xl font-bold mb-4 text-white">Generador de Ecosistemas</h2>
      <p className="text-gray-400 mb-6 text-sm">
        Invoca a un experto para crear un producto digital único ahora mismo.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="block text-xs text-gray-500 mb-1">Nicho</label>
          <select 
            value={selectedNiche} 
            onChange={(e) => setSelectedNiche(e.target.value)}
            className="w-full bg-black border border-[#333] text-white p-3 rounded focus:outline-none focus:border-white transition-colors"
          >
            {NICHES.map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs text-gray-500 mb-1">Experto</label>
          <select 
            value={selectedExpert.id} 
            onChange={(e) => setSelectedExpert(EXPERTS.find(ex => ex.id === e.target.value) || EXPERTS[0])}
            className="w-full bg-black border border-[#333] text-white p-3 rounded focus:outline-none focus:border-white transition-colors"
          >
            {EXPERTS.map(e => <option key={e.id} value={e.id}>{e.name} ({e.focus})</option>)}
          </select>
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-xs text-gray-500 mb-1">Tema Específico</label>
        <input 
          type="text" 
          value={customTopic}
          onChange={(e) => setCustomTopic(e.target.value)}
          placeholder="Ej: Marketing para Introvertidos en 2025"
          className="w-full bg-black border border-[#333] text-white p-3 rounded focus:outline-none focus:border-white transition-colors"
        />
      </div>

      <div className="mb-6">
        <label className="block text-xs text-gray-500 mb-2">Formato de Portada</label>
        <div className="flex gap-2">
            {Object.entries(ImageAspectRatio).map(([key, value]) => (
                <button
                    key={key}
                    onClick={() => setAspectRatio(value)}
                    className={`px-3 py-1 text-xs rounded border ${aspectRatio === value ? 'bg-white text-black border-white' : 'bg-black text-gray-400 border-[#333]'}`}
                >
                    {key}
                </button>
            ))}
        </div>
      </div>

      <button 
        onClick={handleGenerate}
        disabled={loading || !customTopic}
        className="w-full bg-white text-black font-bold py-3 rounded hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
      >
        {loading ? "Invocando Conocimiento..." : "Generar Producto Digital ($9.99 Value)"}
      </button>

      {result && (
        <div className="mt-8 border-t border-[#222] pt-6 animate-fade-in">
          <div className="flex flex-col md:flex-row gap-6">
            {generatedImage && (
               <div className="w-full md:w-1/3">
                 <img src={generatedImage} alt="Course Cover" className="rounded-lg shadow-xl w-full" />
                 {generatedProduct && (
                    <button 
                        onClick={() => onBuy(generatedProduct)}
                        className="block w-full mt-4 text-center bg-green-600 text-white py-2 rounded font-bold hover:bg-green-500 transition-colors shadow-lg shadow-green-900/20"
                    >
                        Comprar Ahora ($9.99)
                    </button>
                 )}
               </div>
            )}
            <div className="w-full md:w-2/3 prose prose-invert prose-sm max-w-none">
              <ReactMarkdown>{result}</ReactMarkdown>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductGenerator;