import React from 'react';
import { GeneratedCourse } from '../types';
import ReactMarkdown from 'react-markdown';

interface CourseDetailsModalProps {
  course: GeneratedCourse;
  imageUrl: string | null;
  isGeneratingImage: boolean;
  onClose: () => void;
  onBuy: () => void;
}

const CourseDetailsModal: React.FC<CourseDetailsModalProps> = ({ 
  course, 
  imageUrl, 
  isGeneratingImage, 
  onClose,
  onBuy
}) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#111] w-full max-w-2xl rounded-2xl border border-[#333] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-[#222] bg-[#0a0a0a] flex justify-between items-start">
          <div>
            <span className={`text-xs font-mono uppercase tracking-widest ${course.categoryColor || 'text-gray-500'}`}>
               {course.categoryLabel || course.category}
            </span>
            <h2 className="text-2xl font-bold text-white mt-2 leading-tight">{course.title}</h2>
            <div className="flex items-center gap-2 mt-2 text-sm text-gray-400">
                <span>By {course.expertName}</span>
                <span>•</span>
                <span>{course.niche}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors p-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto">
            
            {/* Image Section */}
            <div className="w-full aspect-video bg-[#1a1a1a] rounded-lg mb-6 flex items-center justify-center overflow-hidden border border-[#222] relative">
                {isGeneratingImage ? (
                    <div className="flex flex-col items-center gap-3">
                        <div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin"></div>
                        <span className="text-xs text-green-400 font-mono animate-pulse">GENERATING COVER ART...</span>
                    </div>
                ) : imageUrl ? (
                    <img src={imageUrl} alt={course.title} className="w-full h-full object-cover" />
                ) : (
                    <div className="text-gray-600 text-sm">No cover art available</div>
                )}
            </div>

            {/* Description */}
            <div className="prose prose-invert prose-sm max-w-none text-gray-300">
                <h3 className="text-white text-lg font-bold mb-2">Acerca de este producto</h3>
                <p>{course.description}</p>
                {course.contentMarkdown && (
                    <div className="mt-4 pt-4 border-t border-[#222]">
                        <ReactMarkdown>{course.contentMarkdown}</ReactMarkdown>
                    </div>
                )}
            </div>
        </div>
        
        {/* Footer Actions */}
        <div className="p-6 bg-[#0a0a0a] border-t border-[#222] flex gap-4 items-center justify-between">
            <span className="text-3xl font-mono text-green-500 font-bold">$9.99</span>
            <div className="flex gap-3">
                <button 
                    onClick={onClose}
                    className="px-6 py-3 rounded-lg font-medium text-gray-400 hover:text-white hover:bg-[#222] transition-colors"
                >
                    Cerrar
                </button>
                <button 
                    onClick={onBuy}
                    className="bg-white text-black px-8 py-3 rounded-lg font-bold hover:bg-gray-200 transition-all transform hover:scale-105 shadow-lg shadow-white/5"
                >
                    Comprar Ahora
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetailsModal;