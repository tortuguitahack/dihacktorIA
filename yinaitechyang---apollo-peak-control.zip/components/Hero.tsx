import React from 'react';

const Hero: React.FC<{ onStart: () => void }> = ({ onStart }) => {
  return (
    <header className="relative py-24 px-6 text-center overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_#1a1a1a,_#000)] z-0"></div>
      <div className="relative z-10 max-w-3xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 gradient-text tracking-tight">
          La vida es más simple.<br />
          Regalate algo preciado.
        </h1>
        <p className="text-gray-400 text-lg md:text-xl mb-8 max-w-xl mx-auto leading-relaxed">
          Tu yo del futuro te va a dar las gracias.<br />
          <span className="font-semibold text-white">YinAITechYang</span> &mdash; El ecosistema de los 1000 expertos.
        </p>
        <button 
          onClick={onStart}
          className="bg-white text-black px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-200 transition-all transform hover:scale-105 shadow-lg shadow-white/10"
        >
          👉 Elegir por dónde empezar
        </button>
      </div>
      
      <div className="mt-16 p-4 max-w-2xl mx-auto">
        <div className="bg-[#111] border-l-4 border-red-500 p-4 text-left rounded-r-md shadow-2xl">
          <strong className="text-red-500 block mb-1">Advertencia real:</strong>
          <p className="text-gray-300 text-sm">
            Tu celular no es privado. Tus datos no son tuyos. La ignorancia digital se paga caro.
            Accede al conocimiento de la Mente Colectiva ahora.
          </p>
        </div>
      </div>
    </header>
  );
};

export default Hero;