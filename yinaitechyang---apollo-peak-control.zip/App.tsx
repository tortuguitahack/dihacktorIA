import React, { useState, useMemo } from 'react';
import Hero from './components/Hero';
import ProductGenerator from './components/ProductGenerator';
import ChatConsultant from './components/ChatConsultant';
import CheckoutModal from './components/CheckoutModal';
import CourseDetailsModal from './components/CourseDetailsModal';
import { DEFAULT_COURSES } from './constants';
import { GeneratedCourse, ImageAspectRatio } from './types';
import { generateCoverArt } from './services/geminiService';

const App: React.FC = () => {
  const [view, setView] = useState<'home' | 'generator' | 'chat'>('home');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Checkout State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<GeneratedCourse | null>(null);

  // Details Modal State
  const [viewingCourse, setViewingCourse] = useState<GeneratedCourse | null>(null);
  const [detailsImage, setDetailsImage] = useState<string | null>(null);
  const [isGeneratingDetailsImage, setIsGeneratingDetailsImage] = useState(false);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const scrollToCourses = () => {
    setView('home');
    setTimeout(() => {
        document.getElementById('courses')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleBuyClick = (course?: GeneratedCourse) => {
    // If buying from details modal, close details first
    if (viewingCourse) {
        setViewingCourse(null);
    }
    // Default course for chat purchase if none provided
    const productToBuy = course || {
        id: 'AGENT-ACCESS',
        title: 'Acceso Agente Supremo',
        expertName: 'AI Collective',
        niche: 'Consultoría',
        description: 'Acceso ilimitado al conocimiento de 1000 expertos.',
        price: 9.99,
        category: 'Neuro',
        categoryLabel: '⚡ AI · Access',
        categoryColor: 'text-green-400'
    };
    setSelectedProduct(productToBuy);
    setIsCheckoutOpen(true);
  };

  const handleViewDetails = async (course: GeneratedCourse) => {
    setViewingCourse(course);
    setDetailsImage(null); // Reset image
    
    // Check if course already has an image (from CSV or static data if added later)
    if (course.coverImageUrl) {
        setDetailsImage(course.coverImageUrl);
        return;
    }

    setIsGeneratingDetailsImage(true);
    try {
        const prompt = `Professional digital product cover for a course named "${course.title}" by ${course.expertName} in style of ${course.niche}. Minimalist, high quality, dark mode aesthetic, 8k resolution, cinematic lighting.`;
        const imageBase64 = await generateCoverArt(prompt, ImageAspectRatio.Landscape);
        setDetailsImage(imageBase64);
    } catch (error) {
        console.error("Failed to generate cover art for details view", error);
    } finally {
        setIsGeneratingDetailsImage(false);
    }
  };

  const filteredCourses = useMemo(() => {
    if (!searchTerm) return DEFAULT_COURSES;
    const lowerTerm = searchTerm.toLowerCase();
    return DEFAULT_COURSES.filter(course => 
      course.title.toLowerCase().includes(lowerTerm) || 
      course.description.toLowerCase().includes(lowerTerm) ||
      course.category?.toLowerCase().includes(lowerTerm) || 
      false
    );
  }, [searchTerm]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredCourses.length / itemsPerPage);
  const currentCourses = useMemo(() => {
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    return filteredCourses.slice(indexOfFirstItem, indexOfLastItem);
  }, [currentPage, filteredCourses]);

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    document.getElementById('courses')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0b0b0b] text-[#f2f2f2] font-sans selection:bg-white selection:text-black relative">
      
      {/* Checkout Modal Overlay */}
      {isCheckoutOpen && selectedProduct && (
        <CheckoutModal 
          product={selectedProduct} 
          onClose={() => {
            setIsCheckoutOpen(false);
            setSelectedProduct(null);
          }} 
        />
      )}

      {/* Course Details Modal Overlay */}
      {viewingCourse && (
        <CourseDetailsModal 
            course={viewingCourse}
            imageUrl={detailsImage}
            isGeneratingImage={isGeneratingDetailsImage}
            onClose={() => setViewingCourse(null)}
            onBuy={() => handleBuyClick(viewingCourse)}
        />
      )}

      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-[#0b0b0b]/90 backdrop-blur-md z-50 border-b border-[#222]">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <span className="font-bold text-xl cursor-pointer" onClick={() => setView('home')}>YinAITechYang</span>
          <div className="flex gap-4 text-sm font-medium">
            <button 
              onClick={() => setView('home')} 
              className={`${view === 'home' ? 'text-white' : 'text-gray-500'} hover:text-white transition-colors`}
            >
              Catálogo
            </button>
            <button 
              onClick={() => setView('generator')} 
              className={`${view === 'generator' ? 'text-white' : 'text-gray-500'} hover:text-white transition-colors`}
            >
              Crear Producto
            </button>
            <button 
              onClick={() => setView('chat')} 
              className={`${view === 'chat' ? 'text-white' : 'text-gray-500'} hover:text-white transition-colors`}
            >
              Agente Supremo
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="pt-16">
        {view === 'home' && (
          <>
            <Hero onStart={scrollToCourses} />
            
            <section id="courses" className="py-16 px-6 max-w-6xl mx-auto">
              <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Los 100 cursos esenciales</h2>
                  <p className="text-gray-500">Todo lo que necesitás saber. Sin mentiras. Sin humo.</p>
                </div>
                <div className="w-full md:w-auto relative">
                  <input
                    type="text"
                    placeholder="Buscar curso..."
                    value={searchTerm}
                    onChange={(e) => {
                        setSearchTerm(e.target.value);
                        setCurrentPage(1); // Reset page on search
                    }}
                    className="w-full md:w-64 bg-[#111] border border-[#333] text-white px-4 py-2 rounded-lg focus:outline-none focus:border-white transition-colors placeholder-gray-600"
                  />
                  <svg className="w-5 h-5 absolute right-3 top-2.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
              </div>

              {currentCourses.length > 0 ? (
                <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {currentCourses.map((course) => (
                        <div key={course.id} className="bg-[#111] p-6 rounded-lg border border-[#1f1f1f] hover:border-[#333] transition-colors flex flex-col justify-between h-full group relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-gray-700 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div>
                            <span className={`text-xs font-mono uppercase tracking-widest ${course.categoryColor || 'text-gray-500'}`}>
                            {course.categoryLabel || course.category}
                            </span>
                            <h3 className="text-xl font-bold mt-2 mb-3 leading-tight group-hover:text-white transition-colors">{course.title}</h3>
                            <p className="text-sm text-gray-400 mb-4">{course.description}</p>
                            <div className="text-xs text-gray-600 mb-4 flex items-center gap-1">
                            <span>Experto:</span>
                            <span className="text-gray-400">{course.expertName}</span>
                            </div>
                        </div>
                        <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#222] gap-2">
                            <span className="font-mono text-green-500 font-bold text-lg">${course.price}</span>
                            <div className="flex gap-2">
                                <button
                                    onClick={() => handleViewDetails(course)}
                                    className="text-xs bg-[#222] text-gray-300 px-3 py-2 rounded font-medium hover:bg-[#333] transition-colors border border-[#333]"
                                >
                                    Ver Detalles
                                </button>
                                <button 
                                    onClick={() => handleBuyClick(course)}
                                    className="text-xs bg-white text-black px-4 py-2 rounded font-bold hover:bg-gray-200 transition-transform active:scale-95 shadow-lg shadow-white/5"
                                >
                                    Comprar
                                </button>
                            </div>
                        </div>
                        </div>
                    ))}
                    </div>

                    {/* Pagination Controls */}
                    {totalPages > 1 && (
                        <div className="mt-12 flex justify-center items-center gap-2 flex-wrap">
                            <button
                                onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                                disabled={currentPage === 1}
                                className="px-4 py-2 bg-[#111] border border-[#333] rounded-md text-sm text-gray-400 hover:text-white hover:border-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Anterior
                            </button>
                            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                                <button
                                    key={page}
                                    onClick={() => handlePageChange(page)}
                                    className={`w-10 h-10 flex items-center justify-center rounded-md text-sm font-medium border ${
                                        currentPage === page 
                                            ? 'bg-white text-black border-white' 
                                            : 'bg-[#111] border-[#333] text-gray-400 hover:text-white hover:border-gray-500'
                                    }`}
                                >
                                    {page}
                                </button>
                            ))}
                            <button
                                onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                                disabled={currentPage === totalPages}
                                className="px-4 py-2 bg-[#111] border border-[#333] rounded-md text-sm text-gray-400 hover:text-white hover:border-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Siguiente
                            </button>
                        </div>
                    )}
                </>
              ) : (
                <div className="text-center py-20 text-gray-500">
                  <p className="text-xl">No se encontraron cursos que coincidan con tu búsqueda.</p>
                  <button 
                    onClick={() => setSearchTerm('')}
                    className="mt-4 text-white underline hover:text-gray-300"
                  >
                    Ver todos los cursos
                  </button>
                </div>
              )}
              
              <div className="mt-16 text-center">
                  <p className="text-gray-500 mb-4">¿No encuentras lo que buscas?</p>
                  <button 
                    onClick={() => setView('generator')}
                    className="border border-white text-white px-6 py-3 rounded hover:bg-white hover:text-black transition-all"
                  >
                    Invocar Experto & Crear Curso Personalizado
                  </button>
              </div>
            </section>
          </>
        )}

        {view === 'generator' && (
          <div className="max-w-4xl mx-auto py-12 px-6">
            <ProductGenerator onBuy={handleBuyClick} />
          </div>
        )}

        {view === 'chat' && (
          <div className="max-w-4xl mx-auto py-12 px-6">
            <ChatConsultant onBuyAccess={() => handleBuyClick()} />
          </div>
        )}
      </div>

      <footer className="py-8 text-center text-gray-600 text-xs border-t border-[#111] mt-12">
        <p>No vendemos cursos. Vendemos criterio para toda la vida.</p>
        <p className="mt-2 opacity-50">Powered by Gemini 3.0 & Apollo Peak Collective</p>
      </footer>
    </div>
  );
};

export default App;