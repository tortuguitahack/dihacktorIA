import { Expert, PaymentConfig, GeneratedCourse } from './types';

export const NICHES = [
  // Marketing & Sales
  "Ofertas Irresistibles", "Copywriting Hipnótico", "Funnels de Alta Conversión", "Email Marketing Automatizado", "Lanzamientos de 7 Cifras",
  "Ads de Facebook & Instagram", "TikTok Viral Marketing", "YouTube Growth", "LinkedIn B2B Sales", "Influencer Marketing",
  "Neuromarketing", "Psicología de Ventas", "Closing High-Ticket", "E-commerce Dropshipping", "Amazon FBA",
  "Affiliate Marketing", "SEO & Content Marketing", "Branding Personal", "Storytelling para Ventas", "Comunidades de Pago",
  
  // AI & Tech
  "Generative AI Strategy", "Prompt Engineering Avanzado", "Automatización con n8n", "Desarrollo de SaaS", "Machine Learning para Negocios",
  "Chatbots de IA", "Creación de Contenido con IA", "Arte Generativo", "Clonación de Voz IA", "Análisis de Datos con IA",
  "Ciberseguridad Básica", "Web3 Development", "Smart Contracts", "No-Code Development", "App Development Rápido",
  "Realidad Aumentada", "Metaverso & Gaming", "Trading Algorítmico", "Cloud Computing AWS", "DevOps Moderno",

  // Crypto & Finance
  "Bitcoin & Macroeconomía", "DeFi Yield Farming", "NFT Investing", "Trading de Criptomonedas", "Análisis On-Chain",
  "Libertad Financiera", "Inversión en Bolsa", "Bienes Raíces", "Optimización Fiscal", "Protección de Activos",
  "Value Investing", "Venture Capital", "Microeconomía Personal", "Gestión de Deuda", "Ingresos Pasivos",
  "Retiro Anticipado (FIRE)", "Metales Preciosos", "Arbitraje Financiero", "Tokenización de Activos", "Privacidad Financiera",

  // Productivity & Mindset
  "Biohacking & Salud", "Sueño Optimizado", "Nutrición Cognitiva", "Ayuno Intermitente", "Entrenamiento de Fuerza",
  "Gestión del Tiempo", "Deep Work", "Sistemas de Productividad", "Obsidian & Notion Mastery", "Lectura Rápida",
  "Meditación & Mindfulness", "Estoicismo Práctico", "Psicología del Éxito", "Resolución de Conflictos", "Inteligencia Emocional",
  "Liderazgo Exponencial", "Habla en Público", "Negociación Estratégica", "Pensamiento Crítico", "Toma de Decisiones",

  // Creative & Others
  "Escritura Creativa", "Guionismo para Cine", "Producción Musical", "Diseño Gráfico", "Fotografía Profesional",
  "Edición de Video", "Diseño de Interiores", "Arquitectura Sostenible", "Permacultura", "Supervivencia Urbana",
  "Idiomas Acelerados", "Psicología Canina", "Educación en Casa (Homeschooling)", "Cocina de Alto Nivel", "Cata de Vinos",
  "Póker Estratégico", "Ajedrez Avanzado", "Magia & Ilusionismo", "Astrología Financiera", "Espiritualidad Moderna"
];

export const EXPERTS: Expert[] = [
  // 1-10 Marketing
  { id: "1", name: "Alex Hormozi", niche: "Marketing", focus: "Ofertas" },
  { id: "2", name: "Frank Kern", niche: "Marketing", focus: "Copywriting" },
  { id: "3", name: "Seth Godin", niche: "Marketing", focus: "Branding" },
  { id: "4", name: "Gary Vaynerchuk", niche: "Marketing", focus: "Social Media" },
  { id: "5", name: "Neil Patel", niche: "Marketing", focus: "SEO" },
  { id: "6", name: "Russell Brunson", niche: "Marketing", focus: "Funnels" },
  { id: "7", name: "Dan Kennedy", niche: "Marketing", focus: "Direct Response" },
  { id: "8", name: "Robert Cialdini", niche: "Marketing", focus: "Persuasión" },
  { id: "9", name: "Donald Miller", niche: "Marketing", focus: "StoryBrand" },
  { id: "10", name: "Grant Cardone", niche: "Ventas", focus: "10X Sales" },

  // 11-20 AI & Tech
  { id: "11", name: "Sam Altman", niche: "IA", focus: "Estrategia IA" },
  { id: "12", name: "Andrew Ng", niche: "IA", focus: "Machine Learning" },
  { id: "13", name: "Elon Musk", niche: "Tech", focus: "Innovación" },
  { id: "14", name: "Demis Hassabis", niche: "IA", focus: "DeepMind" },
  { id: "15", name: "Yann LeCun", niche: "IA", focus: "Deep Learning" },
  { id: "16", name: "Geoffrey Hinton", niche: "IA", focus: "Redes Neuronales" },
  { id: "17", name: "Lex Fridman", niche: "Tech/Science", focus: "AI Podcast" },
  { id: "18", name: "Naval Ravikant", niche: "Tech/Phil", focus: "Tech Investing" },
  { id: "19", name: "Peter Thiel", niche: "Tech", focus: "Zero to One" },
  { id: "20", name: "Marc Andreessen", niche: "Tech", focus: "Software" },

  // 21-30 Crypto
  { id: "21", name: "Vitalik Buterin", niche: "Crypto", focus: "Ethereum" },
  { id: "22", name: "Satoshi Nakamoto", niche: "Crypto", focus: "Bitcoin" },
  { id: "23", name: "Changpeng Zhao", niche: "Crypto", focus: "Exchange" },
  { id: "24", name: "Michael Saylor", niche: "Crypto", focus: "Bitcoin Strategy" },
  { id: "25", name: "Andreas Antonopoulos", niche: "Crypto", focus: "Education" },
  { id: "26", name: "Gavin Wood", niche: "Crypto", focus: "Polkadot/Web3" },
  { id: "27", name: "Charles Hoskinson", niche: "Crypto", focus: "Cardano" },
  { id: "28", name: "Balaji Srinivasan", niche: "Crypto", focus: "Network State" },
  { id: "29", name: "Raoul Pal", niche: "Macro", focus: "Macro Crypto" },
  { id: "30", name: "PlanB", niche: "Crypto", focus: "Stock-to-Flow" },

  // 31-40 Business
  { id: "31", name: "Jeff Bezos", niche: "Business", focus: "E-commerce" },
  { id: "32", name: "Steve Jobs", niche: "Business", focus: "Product Design" },
  { id: "33", name: "Warren Buffett", niche: "Finance", focus: "Value Investing" },
  { id: "34", name: "Ray Dalio", niche: "Finance", focus: "Principles" },
  { id: "35", name: "Charlie Munger", niche: "Finance", focus: "Mental Models" },
  { id: "36", name: "Bill Gates", niche: "Business", focus: "Software Biz" },
  { id: "37", name: "Richard Branson", niche: "Business", focus: "Virgin Way" },
  { id: "38", name: "Mark Cuban", niche: "Business", focus: "Shark Tank" },
  { id: "39", name: "Kevin O'Leary", niche: "Business", focus: "Startups" },
  { id: "40", name: "Peter Drucker", niche: "Business", focus: "Management" },

  // 41-50 Productivity
  { id: "41", name: "Tim Ferriss", niche: "Productivity", focus: "4-Hour Workweek" },
  { id: "42", name: "James Clear", niche: "Productivity", focus: "Atomic Habits" },
  { id: "43", name: "David Allen", niche: "Productivity", focus: "GTD" },
  { id: "44", name: "Cal Newport", niche: "Productivity", focus: "Deep Work" },
  { id: "45", name: "Ali Abdaal", niche: "Productivity", focus: "Efficiency" },
  { id: "46", name: "Tiago Forte", niche: "Productivity", focus: "Second Brain" },
  { id: "47", name: "Robin Sharma", niche: "Productivity", focus: "5AM Club" },
  { id: "48", name: "Hal Elrod", niche: "Productivity", focus: "Miracle Morning" },
  { id: "49", name: "Greg McKeown", niche: "Productivity", focus: "Essentialism" },
  { id: "50", name: "Stephen Covey", niche: "Productivity", focus: "7 Habits" },

  // 51-60 Psychology/Mindset
  { id: "51", name: "Jordan Peterson", niche: "Psychology", focus: "Meaning" },
  { id: "52", name: "Carl Jung", niche: "Psychology", focus: "Archetypes" },
  { id: "53", name: "Sigmund Freud", niche: "Psychology", focus: "Psychoanalysis" },
  { id: "54", name: "Viktor Frankl", niche: "Psychology", focus: "Logotherapy" },
  { id: "55", name: "Brené Brown", niche: "Psychology", focus: "Vulnerability" },
  { id: "56", name: "Carol Dweck", niche: "Psychology", focus: "Mindset" },
  { id: "57", name: "Daniel Kahneman", niche: "Psychology", focus: "Thinking Fast/Slow" },
  { id: "58", name: "Tony Robbins", niche: "Development", focus: "Unleash Power" },
  { id: "59", name: "Jim Rohn", niche: "Development", focus: "Discipline" },
  { id: "60", name: "Eckhart Tolle", niche: "Spirituality", focus: "Power of Now" },

  // 61-70 Storytelling/Writing
  { id: "61", name: "Joseph Campbell", niche: "Storytelling", focus: "Hero's Journey" },
  { id: "62", name: "Robert McKee", niche: "Storytelling", focus: "Screenwriting" },
  { id: "63", name: "Stephen King", niche: "Writing", focus: "On Writing" },
  { id: "64", name: "J.K. Rowling", niche: "Writing", focus: "World Building" },
  { id: "65", name: "George R.R. Martin", niche: "Writing", focus: "Character Arc" },
  { id: "66", name: "Neil Gaiman", niche: "Writing", focus: "Creativity" },
  { id: "67", name: "Aaron Sorkin", niche: "Writing", focus: "Dialogue" },
  { id: "68", name: "Quentin Tarantino", niche: "Storytelling", focus: "Non-linear" },
  { id: "69", name: "Christopher Nolan", niche: "Storytelling", focus: "Complexity" },
  { id: "70", name: "Dan Brown", niche: "Writing", focus: "Pacing" },

  // 71-80 History/Strategy
  { id: "71", name: "Sun Tzu", niche: "Strategy", focus: "Art of War" },
  { id: "72", name: "Marcus Aurelius", niche: "Philosophy", focus: "Stoicism" },
  { id: "73", name: "Seneca", niche: "Philosophy", focus: "Letters" },
  { id: "74", name: "Machiavelli", niche: "Strategy", focus: "The Prince" },
  { id: "75", name: "Robert Greene", niche: "Strategy", focus: "Power Laws" },
  { id: "76", name: "Yuval Noah Harari", niche: "History", focus: "Sapiens" },
  { id: "77", name: "Jared Diamond", niche: "History", focus: "Civilizations" },
  { id: "78", name: "Niall Ferguson", niche: "History", focus: "Finance History" },
  { id: "79", name: "Carl von Clausewitz", niche: "Strategy", focus: "On War" },
  { id: "80", name: "Napoleon Hill", niche: "History", focus: "Success Laws" },

  // 81-90 Science
  { id: "81", name: "Albert Einstein", niche: "Science", focus: "Relativity" },
  { id: "82", name: "Richard Feynman", niche: "Science", focus: "Teaching" },
  { id: "83", name: "Nikola Tesla", niche: "Science", focus: "Invention" },
  { id: "84", name: "Charles Darwin", niche: "Science", focus: "Evolution" },
  { id: "85", name: "Isaac Newton", niche: "Science", focus: "Physics" },
  { id: "86", name: "Marie Curie", niche: "Science", focus: "Research" },
  { id: "87", name: "Stephen Hawking", niche: "Science", focus: "Cosmology" },
  { id: "88", name: "Carl Sagan", niche: "Science", focus: "Communication" },
  { id: "89", name: "Neil deGrasse Tyson", niche: "Science", focus: "Astrophysics" },
  { id: "90", name: "Leonardo da Vinci", niche: "Art/Science", focus: "Polymath" },

  // 91-100 Modern Influencers
  { id: "91", name: "MrBeast", niche: "Social", focus: "Viral Mechanics" },
  { id: "92", name: "Casey Neistat", niche: "Social", focus: "Vlogging" },
  { id: "93", name: "Joe Rogan", niche: "Social", focus: "Podcasting" },
  { id: "94", name: "Logan Paul", niche: "Social", focus: "Media Empire" },
  { id: "95", name: "MKBHD", niche: "Tech", focus: "Tech Review" },
  { id: "96", name: "PewDiePie", niche: "Social", focus: "Entertainment" },
  { id: "97", name: "David Goggins", niche: "Mindset", focus: "Toughness" },
  { id: "98", name: "Jocko Willink", niche: "Mindset", focus: "Discipline" },
  { id: "99", name: "Andrew Huberman", niche: "Health", focus: "Neuroscience" },
  { id: "100", name: "Peter Attia", niche: "Health", focus: "Longevity" }
];

export const PAYMENT_CONFIG: PaymentConfig = {
  "gateways": [
      {
          "provider": "Stripe",
          "currency": "USD",
          "destination_account": "https://buy.stripe.com/dRmcN54TZfLA0Ij4C89Ve05",
          "payout_schedule": "daily"
      },
      {
          "provider": "KucoinPay",
          "key": "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",
          "secret": "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"
      },
      {
          "provider": "Crypto",
          "wallets": {
              "USDC": "0xeBe965EFe1ab53d2da915134d72e5BdBd5E3C053",
              "USDT": "0xeBe965EFe1ab53d2da915134d72e5BdBd5E3C053",
              "BTC": "bc1qjjgsx3lwa0wz59l89htcpr28j5s7dtmv99fmw0",
              "ETH": "0x2F4bc6f77719AB99BCd6a9b553729bB96C9B8c22"
          },
          "blockchain_api_key": "40c77e88-b4ef-43bc-b2ed-14e4abc93fc6"
      },
      {
          "provider": "BankTransfer",
          "accounts": {
              "USA": {
                  "holder": "Diego Edgardo Cortez Yañez",
                  "routing": "101019644",
                  "account": "219449048779",
                  "bank": "Lead Bank",
                  "type": "CHECKING"
              },
              "Europe": {
                  "holder": "Diego Edgardo Cortez Yañez",
                  "iban": "MT12CFTE28004000000000005456093",
                  "bic": "CFTEMTM1XXX",
                  "bank": "OPENPAYD MALTA"
              },
              "Luxembourg": {
                  "holder": "Diego Edgardo Cortez Yañez",
                  "iban": "LU344080000044110945",
                  "bic": "BCIRLULL",
                  "bank": "Banking Circle"
              },
              "Bolivia": {
                  "holder": "DIEGO EDGARDO CORTEZ YAÑEZ",
                  "account": "4069474188",
                  "bank": "Banco Mercantil Santa Cruz",
                  "type": "Caja de Ahorro",
                  "id": "5808841TJ"
              }
          }
      }
  ],
  "emergency_stop": false
};

// Generating 100 UNIQUE courses using the 100 experts
const generateCourseList = (): GeneratedCourse[] => {
    const courses: GeneratedCourse[] = [];
    
    EXPERTS.forEach((expert, index) => {
        // Assign categories cyclically for visual variety
        const isNeuro = index % 2 === 0;
        
        courses.push({
            id: `PROD-XP-${expert.id}`,
            title: `${expert.focus} Masterclass v${new Date().getFullYear()}`,
            expertName: expert.name,
            niche: expert.niche,
            category: isNeuro ? "Neuro" : "Expert",
            categoryLabel: isNeuro ? "⚡ NEURO · Viral System" : "🧠 EXPERT · Masterclass",
            categoryColor: isNeuro ? "text-yellow-400" : "text-purple-400",
            description: `Aprende ${expert.focus} directamente de la mente de ${expert.name}. Estrategias probadas, sin relleno. Acceso inmediato.`,
            price: 9.99
        });
    });

    return courses;
};

export const DEFAULT_COURSES = generateCourseList();